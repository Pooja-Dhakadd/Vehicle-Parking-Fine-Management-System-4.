
package com.mycompany.main;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class LM {

    // DATABASE CONNECTION
    static final String URL =
        "jdbc:mysql://localhost:3306/parking_management";
    static final String USER = "root";
    static final String PASSWORD = "root";

    static Connection connect() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    static void msg(String s) {
        JOptionPane.showMessageDialog(null, s);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login());
    }

    // LOGIN
    static class Login extends JFrame {
        JTextField username;
        JPasswordField password;

        Login() {
            setTitle("Vehicle Parking Fine Management");
            setSize(420, 300);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

            JPanel p = new JPanel(null);
            p.setBackground(new Color(230, 240, 250));

            JLabel title = new JLabel("ADMIN LOGIN");
            title.setFont(new Font("Arial", Font.BOLD, 24));
            title.setBounds(115, 25, 250, 35);
            p.add(title);

            JLabel u = new JLabel("Username:");
            u.setBounds(50, 90, 100, 25);
            p.add(u);

            username = new JTextField();
            username.setBounds(155, 90, 200, 25);
            p.add(username);

            JLabel pass = new JLabel("Password:");
            pass.setBounds(50, 130, 100, 25);
            p.add(pass);

            password = new JPasswordField();
            password.setBounds(155, 130, 200, 25);
            p.add(password);

            JButton login = new JButton("Login");
            login.setBounds(145, 185, 120, 35);
            p.add(login);

            login.addActionListener(e -> checkLogin());

            add(p);
            setVisible(true);
        }

        void checkLogin() {
            try (Connection con = connect();
                 PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM users WHERE username=? AND password=?")) {

                ps.setString(1, username.getText().trim());
                ps.setString(2, new String(password.getPassword()));

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    dispose();
                    new Dashboard();
                } else {
                    msg("Invalid Username or Password!");
                }

            } catch (Exception e) {
                msg("Database Error: " + e.getMessage());
            }
        }
    }

    // DASHBOARD
    static class Dashboard extends JFrame {

        Dashboard() {
            setTitle("Parking Management Dashboard");
            setSize(550, 450);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

            JPanel p = new JPanel(new GridLayout(5, 1, 15, 15));
            p.setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100));
            p.setBackground(new Color(230, 240, 250));

            JLabel title = new JLabel("VEHICLE PARKING MANAGEMENT",
                    JLabel.CENTER);
            title.setFont(new Font("Arial", Font.BOLD, 20));
            p.add(title);

            JButton add = new JButton("Add Parking Fine");
            JButton view = new JButton("View All Records");
            JButton search = new JButton("Search Vehicle");
            JButton logout = new JButton("Logout");

            p.add(add);
            p.add(view);
            p.add(search);
            p.add(logout);

            add.addActionListener(e -> new AddFine());
            view.addActionListener(e -> new Records());
            search.addActionListener(e -> new Search());

            logout.addActionListener(e -> {
                dispose();
                new Login();
            });

            add(p);
            setVisible(true);
        }
    }

    // ADD FINE
    static class AddFine extends JFrame {

        JTextField vehicle, owner, amount;
        JComboBox<String> violation;

        AddFine() {
            setTitle("Add Parking Fine");
            setSize(450, 400);
            setLocationRelativeTo(null);

            JPanel p = new JPanel(null);
            p.setBackground(new Color(230, 240, 250));

            JLabel title = new JLabel("ADD PARKING FINE");
            title.setFont(new Font("Arial", Font.BOLD, 22));
            title.setBounds(110, 20, 250, 30);
            p.add(title);

            JLabel v = new JLabel("Vehicle Number:");
            v.setBounds(40, 80, 130, 25);
            p.add(v);

            vehicle = new JTextField();
            vehicle.setBounds(180, 80, 200, 25);
            p.add(vehicle);

            JLabel o = new JLabel("Owner Name:");
            o.setBounds(40, 125, 130, 25);
            p.add(o);

            owner = new JTextField();
            owner.setBounds(180, 125, 200, 25);
            p.add(owner);

            JLabel type = new JLabel("Violation:");
            type.setBounds(40, 170, 130, 25);
            p.add(type);

            violation = new JComboBox<>(new String[]{
                "No Parking", "Wrong Parking",
                "Over Speeding", "No Helmet", "Signal Jump"
            });
            violation.setBounds(180, 170, 200, 25);
            p.add(violation);

            JLabel a = new JLabel("Fine Amount:");
            a.setBounds(40, 215, 130, 25);
            p.add(a);

            amount = new JTextField();
            amount.setBounds(180, 215, 200, 25);
            p.add(amount);

            JButton save = new JButton("Save Fine");
            save.setBounds(150, 280, 130, 35);
            p.add(save);

            save.addActionListener(e -> saveFine());

            add(p);
            setVisible(true);
        }

        void saveFine() {
            if (vehicle.getText().trim().isEmpty()
                    || owner.getText().trim().isEmpty()
                    || amount.getText().trim().isEmpty()) {
                msg("Please fill all fields!");
                return;
            }

            try {
                double fine = Double.parseDouble(amount.getText().trim());

                if (fine <= 0) {
                    msg("Enter an amount greater than zero!");
                    return;
                }

                try (Connection con = connect();
                     PreparedStatement ps = con.prepareStatement(
                         "INSERT INTO fines(vehicle_no,owner_name,violation,fine_amount) VALUES(?,?,?,?)")) {

                    ps.setString(1, vehicle.getText().trim());
                    ps.setString(2, owner.getText().trim());
                    ps.setString(3, violation.getSelectedItem().toString());
                    ps.setDouble(4, fine);

                    ps.executeUpdate();
                    msg("Fine Added Successfully!");
                    dispose();
                }

            } catch (NumberFormatException e) {
                msg("Enter a valid fine amount!");
            } catch (Exception e) {
                msg("Error: " + e.getMessage());
            }
        }
    }

    // VIEW RECORDS, UPDATE AND DELETE
    static class Records extends JFrame {

        DefaultTableModel model;
        JTable table;

        Records() {
            setTitle("Parking Fine Records");
            setSize(850, 450);
            setLocationRelativeTo(null);

            model = new DefaultTableModel(
                new String[]{"ID", "Vehicle", "Owner", "Violation",
                    "Amount", "Status", "Date"}, 0
            );

            table = new JTable(model);

            JButton refresh = new JButton("Refresh");
            JButton paid = new JButton("Mark as Paid");
            JButton delete = new JButton("Delete");

            JPanel buttons = new JPanel();
            buttons.add(refresh);
            buttons.add(paid);
            buttons.add(delete);

            refresh.addActionListener(e -> loadRecords());
            paid.addActionListener(e -> markPaid());
            delete.addActionListener(e -> deleteFine());

            add(new JScrollPane(table), BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);

            loadRecords();
            setVisible(true);
        }

        void loadRecords() {
            model.setRowCount(0);

            try (Connection con = connect();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(
                     "SELECT * FROM fines ORDER BY id DESC")) {

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("vehicle_no"),
                        rs.getString("owner_name"),
                        rs.getString("violation"),
                        rs.getDouble("fine_amount"),
                        rs.getString("status"),
                        rs.getTimestamp("created_at")
                    });
                }

            } catch (Exception e) {
                msg("Error: " + e.getMessage());
            }
        }

        void markPaid() {
            int row = table.getSelectedRow();

            if (row == -1) {
                msg("Select a record first!");
                return;
            }

            int id = (int) model.getValueAt(row, 0);

            try (Connection con = connect();
                 PreparedStatement ps = con.prepareStatement(
                     "UPDATE fines SET status='PAID' WHERE id=?")) {

                ps.setInt(1, id);
                ps.executeUpdate();

                msg("Fine Marked as Paid!");
                loadRecords();

            } catch (Exception e) {
                msg("Error: " + e.getMessage());
            }
        }

        void deleteFine() {
            int row = table.getSelectedRow();

            if (row == -1) {
                msg("Select a record first!");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(
                this, "Are you sure you want to delete?",
                "Confirm", JOptionPane.YES_NO_OPTION
            );

            if (confirm != JOptionPane.YES_OPTION) return;

            int id = (int) model.getValueAt(row, 0);

            try (Connection con = connect();
                 PreparedStatement ps = con.prepareStatement(
                     "DELETE FROM fines WHERE id=?")) {

                ps.setInt(1, id);
                ps.executeUpdate();

                msg("Record Deleted!");
                loadRecords();

            } catch (Exception e) {
                msg("Error: " + e.getMessage());
            }
        }
    }

    // SEARCH VEHICLE
    static class Search extends JFrame {

        JTextField vehicle;
        DefaultTableModel model;

        Search() {
            setTitle("Search Vehicle");
            setSize(800, 400);
            setLocationRelativeTo(null);

            JPanel top = new JPanel();
            top.add(new JLabel("Vehicle Number:"));

            vehicle = new JTextField(15);
            top.add(vehicle);

            JButton search = new JButton("Search");
            top.add(search);

            model = new DefaultTableModel(
                new String[]{"ID", "Vehicle", "Owner", "Violation",
                    "Amount", "Status", "Date"}, 0
            );

            JTable table = new JTable(model);

            search.addActionListener(e -> searchVehicle());

            add(top, BorderLayout.NORTH);
            add(new JScrollPane(table), BorderLayout.CENTER);

            setVisible(true);
        }

        void searchVehicle() {
            model.setRowCount(0);

            if (vehicle.getText().trim().isEmpty()) {
                msg("Enter vehicle number!");
                return;
            }

            try (Connection con = connect();
                 PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM fines WHERE vehicle_no LIKE ?")) {

                ps.setString(1, "%" + vehicle.getText().trim() + "%");

                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("vehicle_no"),
                        rs.getString("owner_name"),
                        rs.getString("violation"),
                        rs.getDouble("fine_amount"),
                        rs.getString("status"),
                        rs.getTimestamp("created_at")
                    });
                }

                if (model.getRowCount() == 0) {
                    msg("No Record Found!");
                }

            } catch (Exception e) {
                msg("Error: " + e.getMessage());
            }
        }
    }
}




/*USE parking_management;

INSERT INTO users (username, password)
SELECT 'admin', 'admin'
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE username = 'admin'
);

SELECT * FROM users;
*/